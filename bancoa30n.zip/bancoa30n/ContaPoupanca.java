package bancoa30n;
import javax.swing.JOptionPane;

public class ContaPoupanca extends ContaBancaria {
    
    @Override
    public void consultarSaldo(){
        JOptionPane.showMessageDialog(null,"Seu saldo é: R$ "+saldo);
    }
    
    @Override
    public void depositarValor(){
        double valor;
        valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o valor: "));
        saldo+=valor;
        JOptionPane.showMessageDialog(null,"Seu saldo é: R$ "+saldo);
    }
    
    @Override
    public void sacarValor(){
        double valor;
        valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o valor: "));
        if(saldo<valor){
            JOptionPane.showMessageDialog(null,"Saldo insuficiente");
            System.exit(0);
        }else{
        saldo-=valor;
            JOptionPane.showMessageDialog(null,"Seu saldo é: R$ "+saldo);
        }
    }
}
