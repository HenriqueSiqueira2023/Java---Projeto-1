package bancoa30n;

public class BancoA30N {

    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente();
        cc.depositarValor();
    }
    
}
