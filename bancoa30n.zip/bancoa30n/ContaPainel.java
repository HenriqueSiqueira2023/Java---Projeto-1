package bancoa30n;

public class ContaPainel extends javax.swing.JFrame {
    ContaCorrente cc = new ContaCorrente();

    public ContaPainel() {
        initComponents();
        lblcliente.setText(cc.cliente);
        lblconta.setText(cc.numconta);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bntdeposito = new javax.swing.JButton();
        bntsaque = new javax.swing.JButton();
        lbltitulo = new javax.swing.JLabel();
        btnsaldo = new javax.swing.JButton();
        lblpainel = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        lblcliente = new javax.swing.JLabel();
        lblconta = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bntdeposito.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bntdeposito.setForeground(new java.awt.Color(0, 204, 204));
        bntdeposito.setText("Depósito");
        bntdeposito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntdepositoActionPerformed(evt);
            }
        });

        bntsaque.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bntsaque.setForeground(new java.awt.Color(0, 204, 204));
        bntsaque.setText("Saque");
        bntsaque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntsaqueActionPerformed(evt);
            }
        });

        lbltitulo.setBackground(new java.awt.Color(255, 255, 0));
        lbltitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbltitulo.setForeground(new java.awt.Color(0, 51, 0));
        lbltitulo.setText("Projeto Banco A30N");

        btnsaldo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnsaldo.setForeground(new java.awt.Color(0, 204, 204));
        btnsaldo.setText("Saldo");
        btnsaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaldoActionPerformed(evt);
            }
        });

        lblpainel.setBackground(new java.awt.Color(255, 255, 255));
        lblpainel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblpainel.setText("Seu saldo é");
        lblpainel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblpainel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblpainel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton1.setText("Sair");

        lblcliente.setText("Cliente");

        lblconta.setText("Conta");

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Professor\\Documents\\NetBeansProjects\\BancoA30N\\src\\bancoa30n\\logo_eibneti_topo.png")); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bntsaque, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                            .addComponent(bntdeposito, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                            .addComponent(btnsaldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(45, 45, 45)
                        .addComponent(lblpainel, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lbltitulo)
                        .addGap(100, 100, 100)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblconta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblcliente, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))))
                .addGap(36, 36, 36))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblcliente)
                        .addGap(9, 9, 9))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, Short.MAX_VALUE)
                        .addComponent(lbltitulo)))
                .addGap(18, 18, 18)
                .addComponent(lblconta)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnsaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(31, 31, 31)
                            .addComponent(bntdeposito, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(28, 28, 28)
                            .addComponent(bntsaque, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(lblpainel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(44, 44, 44))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntdepositoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntdepositoActionPerformed
        cc.depositarValor();
    }//GEN-LAST:event_bntdepositoActionPerformed

    private void bntsaqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntsaqueActionPerformed
        cc.sacarValor();
    }//GEN-LAST:event_bntsaqueActionPerformed

    private void btnsaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaldoActionPerformed
        lblpainel.setText("Seu saldo  "+String.format("R$ %.2f",cc.saldo));
    }//GEN-LAST:event_btnsaldoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ContaPainel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ContaPainel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ContaPainel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ContaPainel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ContaPainel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntdeposito;
    private javax.swing.JButton bntsaque;
    private javax.swing.JButton btnsaldo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblcliente;
    private javax.swing.JLabel lblconta;
    private javax.swing.JLabel lblpainel;
    private javax.swing.JLabel lbltitulo;
    // End of variables declaration//GEN-END:variables
}
