package bancoa30n;
import javax.swing.JOptionPane;

public class ContaBancaria {
    public double saldo=0.0;
    public String cliente;
    public String numconta;
    
    public ContaBancaria(){
        saldo=1000;
        cliente = JOptionPane.showInputDialog(null,"Digite o nome do cliente ");
        numconta = JOptionPane.showInputDialog(null,"Digite o nº da conta");
    }
    
    public void consultarSaldo(){
        JOptionPane.showMessageDialog(null,"Seu saldo é: R$ "+saldo);
    }
    
    public void depositarValor(){
        double valor;
        valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o valor: "));
        saldo+=valor;
    }
    
    public void sacarValor(){
        double valor;
        valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o valor: "));
        if(saldo<valor){
            JOptionPane.showMessageDialog(null,"Saldo insuficiente");
            System.exit(0);
        }else{
        saldo-=valor;
            JOptionPane.showMessageDialog(null,"Seu saldo é: R$ "+saldo);
        }
    }
}